close all
clear all
clc
%%
syms m M l F g
syms th th_d th_dd
syms x x_d x_dd 

eq1=(M+m)*x_dd-m*l*th_dd*cos(th)+m*l*th_d^2*sin(th)-F;
eq2=l*th_dd-x_dd*cos(th)-g*sin(th);
u=F;
S=solve(eq1==0, eq2==0, x_dd, th_dd)
%%
x_vet=[x;x_d;th;th_d];
x_vet_dot=[x_d; S.x_dd; th_d; S.th_dd];

A=simplify(jacobian(x_vet_dot,x_vet))
B=simplify(jacobian(x_vet_dot,u))

%% ponto de operacao
x=0;
x_d=0;
th=0;
th_d=0;
u=0;
%%
M=1;
m=0.1;
l=0.4;
g=9.81;
A0=double(simplify(subs(A))) %matriz dinamica
B0=double(simplify(subs(B))) %matriz de entrada
%%
Ts=0.1; %tempo de amostragem
[Ad,Bd]=c2d(A0,B0,Ts)
K=dlqr(Ad,Bd,eye(4),1); %Ganho otimo de realimentacao de estados
%%
T=10; %tempo de simulacao
dt=0.0001;
t=0:dt:T;
Nc=numel(t);
td=0:Ts:T;
Nd=numel(td);
%%
x=zeros(4,Nc);
u=zeros(Nd,1);
%%
Nr=Ts/dt;
kd=1;
fig = figure;
fig.Position = [0 0 1200 500];
%% Parametros PID
Kp=1.5;
Ti=1;
Td=3;
%%
erro_anterior=0;
ui=0;
H=[1 0 0 0;...
   0 0 1 0];
%% condicao inicial
x(:,1)=[0 0 deg2rad(25) 0]';
pendulo=plotPendulo(x(:,1),fig);
for k=1:Nc-1
    %% simula modelo nao-linear pendulo em tempo continuo
    x(:,k+1)=pendulo_model(x(:,k),u(kd),dt,M,m,l);
    if (mod(k,Nr)==0 || k==1) && kd<=numel(td)
        %% simula controlador em tempo discreto
        if k~=1
            kd=kd+1;
        end
        y=H*x(:,k);
        px=y(1); %posicao na direcao x
        theta=y(2); %posicao angular
        %% calcula sinal de erro
        erro=0-theta; %erro de posicao angular
        %% Controle PID
        % up=Kp*erro; %proporcional
        % ud=Kp*Td/Ts*(erro-erro_anterior); %derivativo (euler-backward)
        % ui=ui+Kp*Ts/Ti*erro; %integrativo (euler-backward)
        % u(kd)=up+ud+ui;
        % erro_anterior=erro;
        %% LQR  
        % u(kd)=-K*x(:,k);
        %% atualiza frame da animacao 
        updatePendulo(x(:,k),pendulo);
        pause(0.05)
    end
end
%%
figure
plot(t,rad2deg(x(3,:)))
hold on
stairs(td,u)
legend('theta','u')
xlabel('time (s)')
% figure
% plot(t,x')
% legend('x1','x2','x3','x4')
% xlabel('time (s)')
%%